package pruebasort;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Random;

public class GnomeSortExample {

    public static void main(String[] args) {
        // Generar un array de números aleatorios del 1 al 10
        int[] numeros = generarNumerosAleatorios(10);

        // Mostrar el array antes de ordenar
        System.out.println("Sorteo antes de ordenar: " + Arrays.toString(numeros));

        // Guardar el array antes de ordenar en el archivo
        guardarEnArchivo("numeros_antes.txt", numeros);

        // Aplicar Gnome sort para ordenar el array
        gnomeSort(numeros);

        // Mostrar el array después de ordenar
        System.out.println("Sorteo después de ordenar: " + Arrays.toString(numeros));

        // Guardar el array después de ordenar en el archivo
        guardarEnArchivo("numeros_despues.txt", numeros);
    }

    // Función para generar un array de números aleatorios del 1 al numero que escogamos como max
    private static int[] generarNumerosAleatorios(int max) {
        int[] numeros = new int[max];
        Random random = new Random();

        for (int i = 0; i < max; i++) {
            numeros[i] = random.nextInt(10) + 1; // Números aleatorios del 1 al 10
        }

        return numeros;
    }

    // Empieza el Gnome sort
    private static void gnomeSort(int[] array) {
        int index = 0;

        while (index < array.length) {
            if (index == 0 || array[index] >= array[index - 1]) {
                index++;
            } else {
                // Intercambiar elementos y retroceder
                int temp = array[index];
                array[index] = array[index - 1];
                array[index - 1] = temp;
                index--;
            }
        }
    }

    // Función para guardar un array en un archivo de texto
    private static void guardarEnArchivo(String nombreArchivo, int[] array) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(nombreArchivo))) {
            for (int numero : array) {
                writer.write(Integer.toString(numero));
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
